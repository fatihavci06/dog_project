<?php $__env->startSection('title', 'Send Notification'); ?>

<?php $__env->startSection('content'); ?>

    <h2 class="mb-4">Send Notification 📩</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Success!</strong> <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
 <div class="card shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
    <form action="<?php echo e(route('notifications.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label class="form-label fw-bold">Title</label>
            <input type="text" name="title" class="form-control" placeholder="Enter notification title..." required>
        </div>

        <div class="mb-3">
            <label class="form-label fw-bold">Message</label>
            <textarea name="message" class="form-control" rows="4" placeholder="Enter message content..." required></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label fw-bold">URL (Optional)</label>
            <input type="url" name="url" class="form-control" placeholder="https://example.com">
        </div>

        <div class="mb-3">
            <label class="form-label fw-bold">Select Users</label>
            <select name="user_ids[]" id="userSelect" class="form-select" multiple>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?> (<?php echo e($user->email); ?>)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <div class="form-text">Search and select specific users to send notifications.</div>
        </div>

        <div class="mb-3">
            <label class="form-label fw-bold">Select Roles</label>
            <select name="role_ids[]" id="roleSelect" class="form-select" multiple>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <div class="form-text">You can also target users by their role.</div>
        </div>

        <button type="submit" class="btn btn-primary">
            <i class="fas fa-paper-plane me-1"></i> Send Notification
        </button>
    </form>
 </div> </div> </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- Select2 (User search) -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize searchable multi-selects
        $('#userSelect').select2({
            placeholder: "Search and select users...",
            allowClear: true,
            width: '100%'
        });

        $('#roleSelect').select2({
            placeholder: "Select roles...",
            allowClear: true,
            width: '100%'
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/notifications/create.blade.php ENDPATH**/ ?>