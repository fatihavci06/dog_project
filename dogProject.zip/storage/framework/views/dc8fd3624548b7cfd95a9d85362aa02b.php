<?php $__env->startSection('title', 'Quesetionaire Show'); ?>

<?php $__env->startSection('content'); ?>




    <div class="card shadow mb-4">
        <div class="card-body">

            <div class="card mb-3">

                <div class="card-body">
                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card mb-3">
                            <div class="card-header">
                                <strong><?php echo e($question->question_text); ?></strong>
                            </div>
                            <div class="card-body">
                                <?php $__currentLoopData = $question->userAnswers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="question_<?php echo e($question->id); ?>"
                                            value="<?php echo e($answer->option->id); ?>" checked disabled>
                                        <label class="form-check-label">
                                            <?php echo e($answer->option->option_text); ?> (Rank: <?php echo e($answer->rank); ?>)
                                        </label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                </div>
            </div>



        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/questionnaire/show.blade.php ENDPATH**/ ?>