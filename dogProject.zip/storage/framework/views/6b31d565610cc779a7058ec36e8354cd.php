<?php $__env->startSection('title', 'Sent Notifications'); ?>

<?php $__env->startSection('content'); ?>

    <h2 class="mb-4">Sent Notifications 📬</h2>

    <?php if($notifications->isEmpty()): ?>
        <div class="alert alert-info text-center">
            <i class="fas fa-info-circle me-2"></i> No notifications have been sent yet.
        </div>
    <?php else: ?>
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>Title</th>
                            <th>Message</th>
                            <th>Recipients</th>
                            <th>Sent At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="fw-bold"><?php echo e($notification->title); ?></td>
                                <td><?php echo e(Str::limit($notification->message, 50)); ?></td>
                                <td>
                                    <?php $__currentLoopData = $notification->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="badge bg-info text-dark"><?php echo e($user->name); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td><?php echo e($notification->created_at->format('M d, Y H:i')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        </div>
        <div class="mt-3">
            <?php echo e($notifications->links()); ?>

        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\dogProject\resources\views/notifications/index.blade.php ENDPATH**/ ?>