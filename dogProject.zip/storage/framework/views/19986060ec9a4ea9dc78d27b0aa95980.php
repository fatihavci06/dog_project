<p>Merhaba,</p>
<p>Şifrenizi sıfırlamak için aşağıdaki linke tıklayın:</p>
<p><a href="<?php echo e($url); ?>"><?php echo e($url); ?></a></p>
<p>Bu link 60 dakika boyunca geçerlidir.</p>
<?php /**PATH C:\dogProject\resources\views\emails\reset-password.blade.php ENDPATH**/ ?>