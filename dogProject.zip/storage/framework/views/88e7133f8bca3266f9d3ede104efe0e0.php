<?php $__env->startSection('title', 'User List'); ?>

<?php $__env->startSection('content'); ?>

    <h1 class="h3 mb-4 text-gray-800">User List</h1>

    <!-- Search Form -->
    <form method="GET" action="<?php echo e(route('users')); ?>" class="mb-3">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Search by name"
                value="<?php echo e(request('search')); ?>">
            <button type="submit" class="btn btn-primary">Search</button>
        </div>
    </form>

    <!-- Table -->
    <table class="table table-bordered">
    <thead>
        <tr>
            <th>#ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Status</th>
            <th>Created</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr id="user-<?php echo e($user->id); ?>">
                <td><?php echo e($user->id); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td>
                    <button class="btn btn-sm toggle-status-btn
                        <?php echo e($user->status === 'active' ? 'btn-success' : 'btn-danger'); ?>"
                        data-id="<?php echo e($user->id); ?>">
                        <?php echo e(ucfirst($user->status)); ?>

                    </button>
                </td>
                <td><?php echo e($user->created_at->format('d-m-Y')); ?></td>
                <td>
                    <a href="<?php echo e(route('users.show', $user->id)); ?>" class="btn btn-info btn-sm">
                        <i class="fas fa-user"></i> View
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" class="text-center">No users found.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>



    <!-- Pagination -->
    <div class="mt-3">
        <?php echo e($users->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
   <?php $__env->startSection('scripts'); ?>
<script>
document.querySelectorAll('.toggle-status-btn').forEach(btn => {
    btn.addEventListener('click', function () {
        let userId = this.dataset.id;
        let button = this;

        Swal.fire({
            title: 'Are you sure?',
            text: "Change user status?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, change it!',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                fetch(`/users/${userId}/toggle-status`, {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                        'Content-Type': 'application/json'
                    }
                })
                .then(res => res.json())
                .then(data => {
                    if(data.success){
                        button.textContent = data.status.charAt(0).toUpperCase() + data.status.slice(1);
                        if(data.status === 'active'){
                            button.classList.remove('btn-danger');
                            button.classList.add('btn-success');
                        } else {
                            button.classList.remove('btn-success');
                            button.classList.add('btn-danger');
                        }

                        Swal.fire(
                            'Updated!',
                            'User status has been changed.',
                            'success'
                        )
                    }
                });
            }
        })
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\dogProject\resources\views/users.blade.php ENDPATH**/ ?>