<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>E-posta Doğrulama</title>
</head>
<body>
    <h2>Merhaba <?php echo e($user->name); ?>,</h2>
    <p>Hesabınızı aktifleştirmek için aşağıdaki linke tıklayın:</p>
    <a href="<?php echo e($url); ?>"><?php echo e($url); ?></a>
    <p>Bu link yalnızca bir kez kullanılabilir.</p>
</body>
</html>
<?php /**PATH C:\dogProject\resources\views\emails\verify-email.blade.php ENDPATH**/ ?>