<?php $__env->startSection('title', 'User Profile Details'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="h2 mb-4 text-primary"><i class="fas fa-user-circle mr-2"></i> User Profile Details</h1>

<div class="row">
    
    <div class="col-lg-5 col-md-6 mb-4">
        <div class="card shadow h-100">
            <div class="card-header py-3 bg-primary text-white">
                <h6 class="m-0 font-weight-bold"><i class="fas fa-info-circle mr-2"></i> Basic Information</h6>
            </div>
            <div class="card-body">
                <div class="text-center mb-4">
                    <?php if($user->photo_url): ?>
                        
                        <img src="<?php echo e($user->photo_url); ?>" alt="Profile Photo" class="rounded-circle border p-1" width="120" height="120" style="object-fit: cover;">
                    <?php else: ?>
                        <i class="fas fa-user-circle fa-5x text-secondary"></i>
                    <?php endif; ?>
                </div>

                <ul class="list-group list-group-flush">
                    <li class="list-group-item"><strong><i class="fas fa-signature mr-2"></i> Name:</strong> <?php echo e($user->name); ?></li>
                    <li class="list-group-item"><strong><i class="fas fa-envelope mr-2"></i> Email:</strong> <?php echo e($user->email); ?></li>
                    <li class="list-group-item">
                        <strong><i class="fas fa-toggle-on mr-2"></i> Status:</strong>
                        <span class="badge rounded-pill <?php echo e($user->status == 'active' ? 'bg-success' : 'bg-danger'); ?> p-2">
                            <?php echo e(ucfirst($user->status)); ?>

                        </span>
                    </li>
                    
                    <li class="list-group-item"><strong><i class="far fa-calendar-alt mr-2"></i> Email Verified At:</strong> <?php echo e(\Carbon\Carbon::parse($user->email_verified_at)->format('d M Y H:i')); ?></li>
                </ul>
            </div>
        </div>
    </div>

    
    <div class="col-lg-7 col-md-6 mb-4">
        <div class="card shadow h-100">
            <div class="card-header py-3 bg-info text-white">
                <h6 class="m-0 font-weight-bold"><i class="fas fa-map-marker-alt mr-2"></i> Location & Other Details</h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>City:</strong> <span class="badge bg-secondary text-white"><?php echo e($user->location_city ?? 'N/A'); ?></span></p>
                        <p><strong>District:</strong> <span class="badge bg-secondary text-white"><?php echo e($user->location_district ?? 'N/A'); ?></span></p>
                        <p><strong>User ID:</strong> <span class="badge bg-light text-dark border"><?php echo e($user->id); ?></span></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Role ID (Main):</strong> <?php echo e($user->role_id ?? '-'); ?></p>
                    </div>
                </div>

                <h6 class="mt-3 text-info"><i class="fas fa-book-open mr-2"></i> Biography</h6>
                <p class="border p-3 rounded bg-light">
                    <?php echo e($user->biography ?? 'The user has not added a biography yet. 📝'); ?>

                </p>
            </div>
        </div>
    </div>
</div>

---


<div class="card shadow mb-4">
    <div class="card-header py-3 bg-danger text-white">
        <h3 class="m-0 font-weight-bold"><i class="fas fa-users-cog mr-2"></i> Questionnaire</h3>
    </div>
    <div class="card-body">
        <?php if($user->testUserRoles->isEmpty()): ?>
            <div class="alert alert-info text-center" role="alert">
                <i class="fas fa-exclamation-circle mr-2"></i> No role assignments found for this user.
            </div>
        <?php else: ?>
            <div class="table-responsive">
                
                <table class="table table-bordered table-hover" id="rolesTable" width="100%" cellspacing="0">
                    <thead class="bg-light text-dark">
                        <tr>
                            <th>#ID</th>
                            <th>Role Name 👤</th>
                            <th>Dog Name 🐶</th>
                            <th>Assigned At 📅</th>
                            <th class="text-center">Actions</th> 
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $user->testUserRoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roleAssignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($roleAssignment->id); ?></td>
                                <td><strong><?php echo e($roleAssignment->role->name ?? 'N/A'); ?></strong></td>
                                <td>
                                    
                                    <?php echo e($roleAssignment->dog->first()->name ?? '-'); ?>

                                </td>
                                <td><?php echo e(\Carbon\Carbon::parse($roleAssignment->created_at)->format('d-m-Y H:i')); ?></td>
                                <td class="text-center"> 
                                    
                                    <a href="<?php echo e(route('questionnaire.show',$roleAssignment->id)); ?>" class="btn btn-sm btn-info" title="View Details">
                                        <i class="fas fa-eye"></i> View
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

---


<div class="card shadow mb-4">
    <div class="card-header py-3 bg-warning text-white">
        <h3 class="m-0 font-weight-bold"><i class="fas fa-paw mr-2"></i> User's Furry Friends (Dogs)</h3>
    </div>
    <div class="card-body">
        <?php if($user->userDogs->isEmpty()): ?>
            <div class="alert alert-info text-center" role="alert">
                <i class="fas fa-exclamation-circle mr-2"></i> No dogs found for this user.
            </div>
        <?php else: ?>
            <div class="table-responsive">
                
                <table class="table table-bordered table-hover" id="dogsTable" width="100%" cellspacing="0">
                    <thead class="bg-light text-dark">
                        <tr>
                            <th>#ID</th>
                            <th>Name 🐶</th>
                            <th>Gender</th>
                            <th>Age 🎂</th>
                            <th>Photo</th>
                            <th>Food 🥣</th>
                            <th>Health ⚕️</th>
                            <th>Size</th>
                            <th>Added Date</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $user->userDogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($dog->id); ?></td>
                                <td><strong><?php echo e($dog->name); ?></strong></td>
                                <td>
                                    <?php if($dog->gender == 'male'): ?>
                                        Male ♂️
                                    <?php elseif($dog->gender == 'female'): ?>
                                        Female ♀️
                                    <?php else: ?>
                                        <?php echo e(ucfirst($dog->gender) ?? '-'); ?>

                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($dog->age ?? '-'); ?></td>
                                <td class="text-center">
                                    <?php if($dog->photo_url): ?>
                                        
                                        <img src="<?php echo e($dog->photo_url); ?>" alt="<?php echo e($dog->name); ?> Photo" width="60" height="60" style="object-fit: cover;" class="rounded">
                                    <?php else: ?>
                                        <i class="fas fa-image fa-2x text-muted"></i>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($dog->food ?? '-'); ?></td>
                                <td><?php echo e($dog->health_status ?? '-'); ?></td>
                                <td><?php echo e($dog->size ?? '-'); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($dog->created_at)->format('d-m-Y')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<a href="<?php echo e(route('users')); ?>" class="btn btn-secondary mt-3"><i class="fas fa-arrow-left mr-2"></i> Back to User List</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        // Köpekler Tablosu için 5'erli Sayfalama
        $('#dogsTable').DataTable({
            "pageLength": 5, // Varsayılan sayfa uzunluğu 5
            "lengthMenu": [ [5, 10, 25, 50, -1], [5, 10, 25, 50, "All"] ], // Kullanıcıya sunulacak sayfalama seçenekleri
            "ordering": true,
            "searching": true
        });

        // Role Atamaları Tablosu için 5'erli Sayfalama
        $('#rolesTable').DataTable({
            "pageLength": 5, // Varsayılan sayfa uzunluğu 5
            "lengthMenu": [ [5, 10, 25, 50, -1], [5, 10, 25, 50, "All"] ],
            "ordering": true,
            "searching": true
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/users/show.blade.php ENDPATH**/ ?>