<?php $__env->startSection('title', 'User List'); ?>

<?php $__env->startSection('content'); ?>

<h1 class="h3 mb-4 text-gray-800">User List</h1>

<!-- Search + Role Filter Form -->
<form method="GET" action="<?php echo e(route('users')); ?>" class="row g-2 mb-3">
    <div class="col-md-4">
        <input type="text" name="search" class="form-control" placeholder="Search by name"
            value="<?php echo e(request('search')); ?>">
    </div>

    <div class="col-md-4">
        <select name="role_id" class="form-control">
            <option value="">All Roles</option>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($role->id); ?>" <?php echo e(request('role_id') == $role->id ? 'selected' : ''); ?>>
                    <?php echo e($role->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="col-md-2">
        <button type="submit" class="btn btn-primary w-100">Filter</button>
    </div>

    <div class="col-md-2">
        <a href="<?php echo e(route('users')); ?>" class="btn btn-secondary w-100">Reset</a>
    </div>
</form>

<!-- Table -->
<table class="table table-bordered">
    <thead>
        <tr>
            <th>#ID</th>
            <th>Name</th>
            <th>Role</th>
            <th>Email</th>
            <th>Status</th>
            <th>Created</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr id="user-<?php echo e($user->id); ?>">
                <td><?php echo e($user->id); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->role->name ?? 'No Role'); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td>
                    <button class="btn btn-sm toggle-status-btn
                        <?php echo e($user->status === 'active' ? 'btn-success' : 'btn-danger'); ?>"
                        data-id="<?php echo e($user->id); ?>">
                        <?php echo e(ucfirst($user->status)); ?>

                    </button>
                </td>
                <td><?php echo e($user->created_at->format('d-m-Y')); ?></td>
                <td>
                    <a href="<?php echo e(route('users.show', $user->id)); ?>" class="btn btn-info btn-sm">
                        <i class="fas fa-user"></i> View
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="7" class="text-center">No users found.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<!-- Pagination -->
<div class="mt-3">
    <?php echo e($users->links()); ?>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
document.querySelectorAll('.toggle-status-btn').forEach(btn => {
    btn.addEventListener('click', function () {
        let userId = this.dataset.id;
        let button = this;

        Swal.fire({
            title: 'Are you sure?',
            text: "Change user status?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, change it!',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                fetch(`/users/${userId}/toggle-status`, {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                        'Content-Type': 'application/json'
                    }
                })
                .then(res => res.json())
                .then(data => {
                    if(data.success){
                        button.textContent = data.status.charAt(0).toUpperCase() + data.status.slice(1);
                        if(data.status === 'active'){
                            button.classList.remove('btn-danger');
                            button.classList.add('btn-success');
                        } else {
                            button.classList.remove('btn-success');
                            button.classList.add('btn-danger');
                        }

                        Swal.fire('Updated!', 'User status has been changed.', 'success');
                    }
                });
            }
        })
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/users.blade.php ENDPATH**/ ?>