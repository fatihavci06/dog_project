<?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="mb-2">
    <strong><?php echo e($message->sender->id === auth()->id() ? 'You' : $message->sender->name); ?>:</strong>
    <?php echo e($message->body); ?>

    <small class="text-muted"><?php echo e($message->created_at->format('H:i, d M')); ?></small>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if($messages->count() >= 20): ?>
<div class="text-center my-2">
    <a href="#" id="load-more" data-last-id="<?php echo e($messages->first()->id); ?>">Read More</a>
</div>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/layouts/partials/message_list.blade.php ENDPATH**/ ?>