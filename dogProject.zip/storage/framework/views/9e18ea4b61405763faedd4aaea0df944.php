<?php $__empty_1 = true; $__currentLoopData = $allOtherUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <a href="#"
        class="list-item user-item d-flex align-items-center mb-3 p-2 border rounded text-decoration-none text-dark"
        data-user-id="<?php echo e($user->id); ?>" data-name="<?php echo e($user->name); ?>">
        <img class="rounded-circle mr-3" width="50" height="50"
            src="<?php echo e($user->profile_photo_url ?? asset('storage/profile.jpg')); ?>">
        <div class="flex-fill">
            <strong><?php echo e($user->name); ?></strong>
            <p class="mb-0 text-muted">Start new chat</p>
        </div>
    </a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p class="text-center text-gray-500" id="no-other-users">No other users found.</p>
<?php endif; ?>


<div class="mt-3" id="user-pagination-links">
    <?php echo e($allOtherUsers->links('pagination::bootstrap-4')); ?>

</div>
<?php /**PATH /var/www/html/resources/views/messages/partials/user_list_items.blade.php ENDPATH**/ ?>