<?php $__env->startSection('title', '3d Tasarım'); ?>

<?php $__env->startSection('content'); ?>

<h1 class="h3 mb-4 text-gray-800"></h1>

<div class="row mb-4">

</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>

</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\dogProject\resources\views/welcome.blade.php ENDPATH**/ ?>