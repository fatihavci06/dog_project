<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    //
    public function index(Request $request)
    {
        $query = User::where(function ($q) {
            $q->where('role_id', '!=', 1)
                ->orWhereNull('role_id');
        });

        // Search özelliği
        if ($request->filled('search')) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        $users = $query->paginate(20)->withQueryString();

        return view('users', compact('users'));
    }
    public function toggleStatus(User $user)
    {
        $user->status = $user->status === 'active' ? 'inactive' : 'active';
        $user->save();

        return response()->json([
            'success' => true,
            'status' => $user->status
        ]);
    }
    public function show(User $user)
    {
        $user->load('userDogs'); // ilişkili köpekleri yükle
        return view('users.show', compact('user'));
    }
}
