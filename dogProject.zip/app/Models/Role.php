<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Role extends Model
{
    //
    protected $fillable = ['name', 'description'];
    public function users()
    {
        return $this->belongsToMany(User::class, 'role_user');
    }
     public function notifications()
    {
        return $this->belongsToMany(Notification::class, 'notification_role')
                    ->withTimestamps();
    }
}
