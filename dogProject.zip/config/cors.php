<?php

return [
    'paths' => ['*'], // Tüm path'lere izin ver

    'allowed_methods' => ['*'],

    'allowed_origins' => ['*'], // Tüm origin'lere izin ver

    'allowed_origins_patterns' => [],

    'allowed_headers' => ['*'],

    'exposed_headers' => [],

    'max_age' => 0,

    'supports_credentials' => false,
];
