 <footer class="sticky-footer bg-white">
     <div class="container my-auto">
         <div class="copyright text-center my-auto">

         </div>
     </div>
 </footer>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        if (window.innerWidth <= 768) {
            document.getElementById('accordionSidebar').classList.add('toggled');
        }
    });

</script>
