<p>Merhaba,</p>
<p>Şifrenizi sıfırlamak için aşağıdaki linke tıklayın:</p>
<p><a href="{{ $url }}">{{ $url }}</a></p>
<p>Bu link 60 dakika boyunca geçerlidir.</p>
